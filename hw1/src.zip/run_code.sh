#!/bin/sh

python3 apriori.py
