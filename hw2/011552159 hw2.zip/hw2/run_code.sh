#!/bin/sh
python3 /HW2.py