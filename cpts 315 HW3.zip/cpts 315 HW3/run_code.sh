#!/bin/sh

python3 HW3.py